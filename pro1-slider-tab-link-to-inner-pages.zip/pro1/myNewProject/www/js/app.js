// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
var app = angular.module('starter', ['ionic','ngSanitize'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('tabs', {
      url: "/tab",
      abstract: true,
      templateUrl: "templates/tabs.html"
    })

     .state('tabs.side-menu', {
      url: "/side-menu",
         views: {
        'home-tab': {
          templateUrl: "templates/side-menu.html",
         // controller: 'HomeTabCtrl'
        }
      }
    })

    .state('tabs.home', {
      url: "/home",
      views: {
        'home-tab': {
          templateUrl: "templates/home.html",
         // controller: 'HomeTabCtrl'
        }
      }
    })

    .state('tabs.fact1', {
      url: "/fact1",
      views: {
        'home-tab': {
          templateUrl: "templates/fact1.html",
         // controller: 'HomeTabCtrl'
        }
      }
    })

        .state('tabs.fact2', {
      url: "/fact2",
      views: {
        'home-tab': {
          templateUrl: "templates/fact2.html",
         // controller: 'HomeTabCtrl'
        }
      }
    })

     .state('tabs.fact3', {
      url: "/fact3",
      views: {
        'home-tab': {
          templateUrl: "templates/fact3.html",
         // controller: 'HomeTabCtrl'
        }
      }
    })

.state('tabs.about',{
url: "/about",
views : {
  'about-tab':{
    templateUrl:"templates/about.html",
  }
}
})

 
.state('tabs.contact',{
    url:"/contact",
    views:{
      'contact-tab':{
        templateUrl:"templates/contact.html"
      }
    }
})

 

    .state('tabs.navstack', {
      url: "/navstack",
      views: {
        'home-tab': {
          templateUrl: "templates/nav-stack.html"
        }
      }
    })

/*.state('tabs.fact1',{
  url:"/fact1.html",
  views:{
    'fact-tab':{
      templateUrl:"templates/fact1.html"
    }
  }
})*/

/*  .state('tabs.fact1', {
                url: "/fact1",
                templateUrl: "templates/fact1.html",
               
            })*/

   $urlRouterProvider.otherwise("/tab/home");

})

.controller('NavCtrl', function($scope, $ionicSideMenuDelegate) {
  $scope.showMenu = function () {
    $ionicSideMenuDelegate.toggleLeft();
  };
  $scope.showRightMenu = function () {
    $ionicSideMenuDelegate.toggleRight();
  };
})