### :point_right: This app base repo has moved to the [ionic-team/starters](https://github.com/ionic-team/starters/tree/master/ionic1/base) repo! :point_left:
